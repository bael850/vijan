import type { Metadata } from "next";
import { getAllPosts } from "@/lib/data";
import VersListClient from "@/components/VersListClient";
import Reveal from "@/components/Reveal";

export const metadata: Metadata = {
  title: "Vers",
  description: "Cerpen, cerbung, sajak, dan tulisan lainnya.",
};

export default async function VersPage({
  searchParams,
}: {
  searchParams: Promise<{ rubrik?: string }>;
}) {
  const [posts, { rubrik }] = await Promise.all([getAllPosts(), searchParams]);
  const initial = rubrik === "rekomendasi" ? "rekomendasi" : "semua";

  return (
    <main className="min-h-screen bg-black text-white">
      <div className="max-w-5xl mx-auto px-4 md:px-6 py-16 md:py-24">
        <Reveal>
          <h1 className="font-display text-5xl md:text-7xl leading-[1.05] mb-16">
            How Worlds Are Woven
          </h1>
        </Reveal>

        <VersListClient posts={posts} initial={initial} />
      </div>
    </main>
  );
}
